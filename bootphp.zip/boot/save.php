<?php

echo "entro";

//Metodos get post 
$email = $_POST['email'];
echo $email;

$pass= $_POST['password'];
echo $pass;

?>